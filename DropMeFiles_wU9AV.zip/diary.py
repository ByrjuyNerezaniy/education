import datetime

def write_in_diary():
    """Запись в дневник."""
    print("""Запись в дневник.""")

def read_in_diary():
    """Чтение дневника."""
    print("""Чтение дневника.""")

def change_day():
    """Смена дня. Работа будильника"""
    print("""Смена дня. Работа будильника""")

def check_command(command):
    """Обработка команд."""
    match command:
        case 'запись': write_in_diary()
        case 'будильник': ...
        case 'чтение': read_in_diary()
        case 'удаление': ...
        case 'смена дня': change_day()

def main():
    last_time = datetime.datetime.now()
    while True:
        if datetime.datetime.now() - last_time > datetime.timedelta(seconds=3):
            change_day()
            last_time = datetime.datetime.now()

if __name__ == "__main__":
    main()
