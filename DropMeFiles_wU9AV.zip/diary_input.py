from diary import check_command

while True:
    command = input()
    check_command(command)